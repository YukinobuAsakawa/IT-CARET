<?php
/**
* @package post-count-plugin
* @version 1.0
*/
/*
Plugin Name: post-count-plugin
Plugin URI:
Description: WordPressの投稿件数をカウントして表示します。
Author: Yukinobu Asakwa
Version: 1.0
Author URI:
License:GPLv2
*/

function post_count_plugin(){
$count_posts = wp_count_posts();
$posts = $count_posts->publish;
echo '<p>現在の記事数は'.$posts.'件です</P>';
  }
//公開済みの投稿件数をカウントして出力する。

add_action('admin_notices', 'post_count_plugin');
//管理画面に表示する。
add_action('wp_footer','post_count_plugin');
//footerに表示する。

class count_widget extends WP_Widget {
	function __construct() {
		parent::__construct(false, '公開済みの投稿数をカウントするウィジェット');
	}

	//公開側での表示
	function widget($args, $instance) {
    post_count_plugin();
	}

	//ウィジェットの設定画面で
	function update($new_instance, $old_instance) {}

	//ウィジェットの設定画面
	function form($instance) {}
}
add_action('widgets_init', create_function('', 'return register_widget("count_widget");'));
